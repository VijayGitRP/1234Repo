package com.vijay.project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectassignApplicationTests {

	@Test
	void contextLoads() {
	}

}
